package com.example.webparser.events.interfaces;

public interface SearchCompletedCallback {
    void SearchHasCompleted();
}
