package com.example.devployedapp;

import android.view.View;

public interface JobCardBlowUpInterface {
    void OnCardClick(int position);
}
