package com.example.webparser.targets;

public class Tesla {



}
