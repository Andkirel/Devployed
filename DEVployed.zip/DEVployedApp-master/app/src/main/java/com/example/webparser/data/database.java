package com.example.webparser.data;

public class database {

}
