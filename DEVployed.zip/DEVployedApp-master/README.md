# DevPloyedApp

Front-end UI for the **DevPloyed.App** Project.

Back-end system: https://github.com/TristanAncelet/Devployed.App.WebParser

<br />
<br />

## Front-End Developers

| Name          | Number             | Email                          |
|---------------|--------------------|--------------------------------|
| Kera Linn     | +1 (###) ###-####  | kera.linn@yahoo.com            |
| Jonah Pickett | +1 (407) 456-3864  | jhpickett@student.fullsail.edu |


## Back-End Developers
| Name            | Number            | Email                    |
|-----------------|-------------------|--------------------------|
| Andrew Ruiz     | +1 (936) 232-2687 | aruiz52698@outlook.com   |
| Tristan Ancelet | +1 (337) 499-0568 | tristanancelet@yahoo.com | 
